<?php

if (! defined('ABSPATH')) {
    exit;
}

class WCDG_Settings
{
    public const OPTION_KEY = 'wcdg_settings';

    private const LEGACY_BUNDLED_WALLET_HASHES = array(
        '3a40a900e01bc1f405691528bba9f5a7453ba5fa137cb5578822ce4a728b57fa',
        '070bc22a0c389fd02740ce609080a04da21d5bc5c08e9f7d00bf31bc3300e03b',
        '6578255387d06004447b4d46bb05189d70c80bd1b162a99670161d26e9813166',
    );

    public static function default_settings(): array
    {
        return array(
            'merchant_name' => get_bloginfo('name') ?: 'Merchant',
            'brand_tagline' => __('Direct wallet checkout without a custodial processor.', 'wp-crypto-direct-gateway'),
            'brand_primary_color' => '#d6ff4b',
            'brand_secondary_color' => '#63b9ff',
            'brand_logo_url' => '',
            'default_fiat_currency' => 'USD',
            'payment_window_minutes' => 30,
            'watcher_enabled' => 1,
            'callback_secret' => wp_generate_password(24, false, false),
            'qr_provider' => 'quickchart',
            'wallets' => self::default_wallet_templates(),
        );
    }

    /**
     * Wallet templates ship without payout addresses on purpose. Rows stay
     * hidden from checkout until the store admin pastes their own address.
     */
    public static function default_wallet_templates(): array
    {
        return array(
            array(
                'uid' => 'btc-bitcoin',
                'enabled' => 1,
                'symbol' => 'BTC',
                'name' => 'Bitcoin',
                'network' => 'Bitcoin',
                'coingecko_id' => 'bitcoin',
                'address' => '',
                'static_qr_url' => '',
                'qr_display_mode' => 'dynamic',
                'confirmations' => 1,
            ),
            array(
                'uid' => 'eth-ethereum',
                'enabled' => 1,
                'symbol' => 'ETH',
                'name' => 'Ethereum',
                'network' => 'Ethereum',
                'coingecko_id' => 'ethereum',
                'address' => '',
                'static_qr_url' => '',
                'qr_display_mode' => 'dynamic',
                'confirmations' => 12,
            ),
            array(
                'uid' => 'usdt-trc20',
                'enabled' => 1,
                'symbol' => 'USDT',
                'name' => 'Tether',
                'network' => 'TRC20',
                'coingecko_id' => 'tether',
                'address' => '',
                'static_qr_url' => '',
                'qr_display_mode' => 'dynamic',
                'confirmations' => 1,
            ),
            array(
                'uid' => 'usdt-erc20',
                'enabled' => 1,
                'symbol' => 'USDT',
                'name' => 'Tether',
                'network' => 'ERC20',
                'coingecko_id' => 'tether',
                'address' => '',
                'static_qr_url' => '',
                'qr_display_mode' => 'dynamic',
                'confirmations' => 1,
            ),
            array(
                'uid' => 'trx-trc20',
                'enabled' => 1,
                'symbol' => 'TRX',
                'name' => 'TRON',
                'network' => 'TRC20',
                'coingecko_id' => 'tron',
                'address' => '',
                'static_qr_url' => '',
                'qr_display_mode' => 'dynamic',
                'confirmations' => 1,
            ),
        );
    }

    public function hooks(): void
    {
        add_action('admin_menu', array($this, 'register_admin_menus'));
        add_action('admin_post_wcdg_save_settings', array($this, 'handle_settings_save'));
    }

    public function register_admin_menus(): void
    {
        add_menu_page(
            __('Crypto Gateway', 'wp-crypto-direct-gateway'),
            __('Crypto Gateway', 'wp-crypto-direct-gateway'),
            'manage_options',
            'wcdg-settings',
            array($this, 'render_settings_page'),
            'dashicons-money-alt',
            56
        );
    }

    public static function get_settings(): array
    {
        $settings = get_option(self::OPTION_KEY, array());
        $settings = is_array($settings) ? $settings : array();
        $defaults = self::default_settings();

        if (isset($settings['wallets']) && is_array($settings['wallets'])) {
            // Saved wallets are authoritative: never merge template rows back
            // in, so deleted rows stay deleted and addresses are only ever
            // what the admin saved.
            $settings['wallets'] = array_values(array_map(
                array(__CLASS__, 'sanitize_wallet'),
                array_filter($settings['wallets'], 'is_array')
            ));
        } else {
            $settings['wallets'] = $defaults['wallets'];
        }

        return wp_parse_args($settings, $defaults);
    }

    public static function get_wallets(bool $enabled_only = true): array
    {
        $settings = self::get_settings();
        $wallets = isset($settings['wallets']) && is_array($settings['wallets']) ? $settings['wallets'] : array();

        $wallets = array_values(array_filter(array_map(array(__CLASS__, 'sanitize_wallet'), $wallets), function (array $wallet) use ($enabled_only): bool {
            if ($wallet['symbol'] === '' || ! self::has_usable_wallet_address($wallet['address'])) {
                return false;
            }

            if (! $enabled_only) {
                return true;
            }

            return (bool) $wallet['enabled'];
        }));

        return $wallets;
    }

    public static function has_usable_wallet_address(string $address): bool
    {
        $normalized = trim($address);

        if ($normalized === '') {
            return false;
        }

        return ! self::is_legacy_bundled_wallet_address($normalized);
    }

    public static function has_legacy_bundled_wallets(array $wallets): bool
    {
        foreach ($wallets as $wallet) {
            if (! is_array($wallet)) {
                continue;
            }

            if (self::is_legacy_bundled_wallet_address((string) ($wallet['address'] ?? ''))) {
                return true;
            }
        }

        return false;
    }

    private static function is_legacy_bundled_wallet_address(string $address): bool
    {
        $normalized = trim($address);

        if ($normalized === '') {
            return false;
        }

        return in_array(hash('sha256', $normalized), self::LEGACY_BUNDLED_WALLET_HASHES, true);
    }

    public static function find_wallet(string $symbol): ?array
    {
        foreach (self::get_wallets(false) as $wallet) {
            if (strcasecmp($wallet['symbol'], $symbol) === 0) {
                return $wallet;
            }
        }

        return null;
    }

    public static function find_wallet_by_uid(string $uid): ?array
    {
        foreach (self::get_wallets(false) as $wallet) {
            if (($wallet['uid'] ?? '') === $uid) {
                return $wallet;
            }
        }

        return null;
    }

    public static function find_wallet_by_symbol_and_network(string $symbol, string $network): ?array
    {
        foreach (self::get_wallets(false) as $wallet) {
            if (strcasecmp((string) $wallet['symbol'], $symbol) === 0 && strcasecmp((string) $wallet['network'], $network) === 0) {
                return $wallet;
            }
        }

        return null;
    }

    public function handle_settings_save(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to update these settings.', 'wp-crypto-direct-gateway'));
        }

        check_admin_referer('wcdg_save_settings');

        $wallets = array();
        $invalid_wallets = array();
        $used_uids = array();
        $submitted_wallets = isset($_POST['wallets']) && is_array($_POST['wallets']) ? wp_unslash($_POST['wallets']) : array();

        foreach ($submitted_wallets as $wallet) {
            if (! is_array($wallet)) {
                continue;
            }

            $sanitized = self::sanitize_wallet($wallet);

            // Skip fully blank rows (e.g. an added row that was never filled in).
            if ($sanitized['symbol'] === '' && $sanitized['name'] === '' && $sanitized['address'] === '') {
                continue;
            }

            if ($sanitized['uid'] === '') {
                $sanitized['uid'] = self::build_wallet_uid($sanitized['symbol'], $sanitized['network']);
            }

            $base_uid = $sanitized['uid'] !== '' ? $sanitized['uid'] : 'wallet';
            $unique_uid = $base_uid;
            $suffix = 2;
            while (isset($used_uids[$unique_uid])) {
                $unique_uid = $base_uid . '-' . $suffix;
                $suffix++;
            }
            $used_uids[$unique_uid] = true;
            $sanitized['uid'] = $unique_uid;

            // A wallet with an address that does not match its network format
            // must never reach checkout: disable it and flag it to the admin.
            if ($sanitized['address'] !== '' && ! WCDG_Crypto::validate_address($sanitized['address'], $sanitized['symbol'], $sanitized['network'])) {
                $sanitized['enabled'] = 0;
                $invalid_wallets[] = trim($sanitized['symbol'] . ' ' . $sanitized['network']);
            }

            $wallets[] = $sanitized;
        }

        $settings = array(
            'merchant_name' => sanitize_text_field(wp_unslash($_POST['merchant_name'] ?? '')),
            'brand_tagline' => sanitize_text_field(wp_unslash($_POST['brand_tagline'] ?? '')),
            'brand_primary_color' => sanitize_hex_color(wp_unslash($_POST['brand_primary_color'] ?? '')) ?: '#d6ff4b',
            'brand_secondary_color' => sanitize_hex_color(wp_unslash($_POST['brand_secondary_color'] ?? '')) ?: '#63b9ff',
            'brand_logo_url' => esc_url_raw(wp_unslash($_POST['brand_logo_url'] ?? '')),
            'default_fiat_currency' => strtoupper(sanitize_text_field(wp_unslash($_POST['default_fiat_currency'] ?? 'USD'))),
            'payment_window_minutes' => max(5, absint($_POST['payment_window_minutes'] ?? 30)),
            'watcher_enabled' => empty($_POST['watcher_enabled']) ? 0 : 1,
            'callback_secret' => sanitize_text_field(wp_unslash($_POST['callback_secret'] ?? '')),
            'qr_provider' => 'quickchart',
            'wallets' => $wallets,
        );

        if ($settings['callback_secret'] === '') {
            $settings['callback_secret'] = wp_generate_password(24, false, false);
        }

        update_option(self::OPTION_KEY, wp_parse_args($settings, self::default_settings()));

        $redirect_args = array(
            'page' => 'wcdg-settings',
            'updated' => '1',
        );

        if ($invalid_wallets !== array()) {
            $redirect_args['wcdg_invalid'] = rawurlencode(implode(', ', array_unique($invalid_wallets)));
        }

        wp_safe_redirect(add_query_arg($redirect_args, admin_url('admin.php')));
        exit;
    }

    public function render_settings_page(): void
    {
        $settings = self::get_settings();
        $wallets = isset($settings['wallets']) && is_array($settings['wallets']) ? $settings['wallets'] : array();
        $has_legacy_wallets = self::has_legacy_bundled_wallets($wallets);
        ?>
        <div class="wrap wcdg-admin-shell">
            <section class="wcdg-admin-hero">
                <div>
                    <p class="wcdg-admin-kicker"><?php esc_html_e('Premium Crypto Checkout', 'wp-crypto-direct-gateway'); ?></p>
                    <h1><?php esc_html_e('WP Crypto Direct Gateway', 'wp-crypto-direct-gateway'); ?></h1>
                    <p><?php esc_html_e('Create direct wallet payment requests with QR codes, live rates, a callback endpoint, and optional WooCommerce checkout support.', 'wp-crypto-direct-gateway'); ?></p>
                </div>
                <div class="wcdg-admin-hero-badges">
                    <span><?php esc_html_e('Wallets', 'wp-crypto-direct-gateway'); ?> <?php echo esc_html((string) count(WCDG_Settings::get_wallets(false))); ?></span>
                    <span><?php esc_html_e('Watcher', 'wp-crypto-direct-gateway'); ?> <?php echo ! empty($settings['watcher_enabled']) ? esc_html__('Enabled', 'wp-crypto-direct-gateway') : esc_html__('Disabled', 'wp-crypto-direct-gateway'); ?></span>
                    <span><?php echo esc_html($settings['default_fiat_currency']); ?></span>
                </div>
            </section>

            <?php if (isset($_GET['updated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Settings saved.', 'wp-crypto-direct-gateway'); ?></p></div>
            <?php endif; ?>

            <?php if (! empty($_GET['wcdg_invalid'])) : ?>
                <div class="notice notice-error">
                    <p>
                        <?php
                        printf(
                            /* translators: %s: comma-separated list of wallet symbols/networks */
                            esc_html__('The following wallets were disabled because their address does not match the expected format for the network: %s. Please double-check and re-enable them.', 'wp-crypto-direct-gateway'),
                            esc_html(rawurldecode(sanitize_text_field(wp_unslash($_GET['wcdg_invalid']))))
                        );
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php if ($has_legacy_wallets) : ?>
                <div class="notice notice-warning"><p><?php esc_html_e('Some wallet rows still contain legacy bundled sample addresses. Those rows are ignored at checkout until you replace them with your own wallet addresses.', 'wp-crypto-direct-gateway'); ?></p></div>
            <?php endif; ?>

            <?php if (empty(self::get_wallets())) : ?>
                <div class="notice notice-warning"><p><?php esc_html_e('No enabled wallet has a payout address yet. Customers will not see any crypto payment option until you paste at least one wallet address below and save.', 'wp-crypto-direct-gateway'); ?></p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="wcdg_save_settings" />
                <?php wp_nonce_field('wcdg_save_settings'); ?>

                <div class="wcdg-admin-grid">
                    <section class="wcdg-admin-panel">
                        <div class="wcdg-admin-panel-header">
                            <h2><?php esc_html_e('Brand & Gateway', 'wp-crypto-direct-gateway'); ?></h2>
                            <p><?php esc_html_e('Configure brand presentation, payout defaults, and the automatic watcher.', 'wp-crypto-direct-gateway'); ?></p>
                        </div>
                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="wcdg-merchant-name"><?php esc_html_e('Merchant name', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="text" id="wcdg-merchant-name" class="regular-text" name="merchant_name" value="<?php echo esc_attr($settings['merchant_name']); ?>" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-brand-tagline"><?php esc_html_e('Brand tagline', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="text" id="wcdg-brand-tagline" class="regular-text" name="brand_tagline" value="<?php echo esc_attr($settings['brand_tagline']); ?>" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-brand-primary"><?php esc_html_e('Primary color', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="color" id="wcdg-brand-primary" name="brand_primary_color" value="<?php echo esc_attr($settings['brand_primary_color']); ?>" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-brand-secondary"><?php esc_html_e('Secondary color', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="color" id="wcdg-brand-secondary" name="brand_secondary_color" value="<?php echo esc_attr($settings['brand_secondary_color']); ?>" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-brand-logo"><?php esc_html_e('Logo URL', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td>
                                        <input type="url" id="wcdg-brand-logo" class="regular-text code" name="brand_logo_url" value="<?php echo esc_attr($settings['brand_logo_url']); ?>" />
                                        <p class="description"><?php esc_html_e('Optional remote logo image for the customer payment panel and WooCommerce emails.', 'wp-crypto-direct-gateway'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-default-fiat"><?php esc_html_e('Default fiat currency', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="text" id="wcdg-default-fiat" class="regular-text" name="default_fiat_currency" value="<?php echo esc_attr($settings['default_fiat_currency']); ?>" maxlength="10" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-payment-window"><?php esc_html_e('Payment window (minutes)', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td><input type="number" id="wcdg-payment-window" class="small-text" min="5" name="payment_window_minutes" value="<?php echo esc_attr((string) $settings['payment_window_minutes']); ?>" /></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e('Automatic watcher', 'wp-crypto-direct-gateway'); ?></th>
                                    <td>
                                        <label><input type="checkbox" name="watcher_enabled" value="1" <?php checked(! empty($settings['watcher_enabled'])); ?> /> <?php esc_html_e('Enable automatic blockchain polling for BTC, ETH, USDT ERC20, and USDT TRC20.', 'wp-crypto-direct-gateway'); ?></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-callback-secret"><?php esc_html_e('Callback secret', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td>
                                        <input type="text" id="wcdg-callback-secret" class="regular-text code" name="callback_secret" value="<?php echo esc_attr($settings['callback_secret']); ?>" />
                                        <p class="description"><?php esc_html_e('Use this secret in the X-WCDG-Signature header when an external watcher posts payment confirmations.', 'wp-crypto-direct-gateway'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="wcdg-qr-provider"><?php esc_html_e('QR provider', 'wp-crypto-direct-gateway'); ?></label></th>
                                    <td>
                                        <select id="wcdg-qr-provider" name="qr_provider">
                                            <option value="quickchart" <?php selected($settings['qr_provider'], 'quickchart'); ?>><?php esc_html_e('QuickChart', 'wp-crypto-direct-gateway'); ?></option>
                                        </select>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </section>

                    <aside class="wcdg-admin-panel wcdg-admin-sidebar">
                        <div class="wcdg-admin-panel-header">
                            <h2><?php esc_html_e('Launch Checklist', 'wp-crypto-direct-gateway'); ?></h2>
                            <p><?php esc_html_e('Use this before publishing the gateway live.', 'wp-crypto-direct-gateway'); ?></p>
                        </div>
                        <ul class="wcdg-checklist">
                            <li><?php esc_html_e('Paste each wallet address manually and confirm the network.', 'wp-crypto-direct-gateway'); ?></li>
                            <li><?php esc_html_e('Verify the brand colors and logo render correctly.', 'wp-crypto-direct-gateway'); ?></li>
                            <li><?php esc_html_e('Place one test order per enabled asset.', 'wp-crypto-direct-gateway'); ?></li>
                            <li><?php esc_html_e('Keep watcher enabled unless you use an external monitoring service.', 'wp-crypto-direct-gateway'); ?></li>
                            <li><?php esc_html_e('Export a production zip from the packaging script before deployment.', 'wp-crypto-direct-gateway'); ?></li>
                        </ul>
                        <div class="wcdg-admin-callout">
                            <strong><?php esc_html_e('Installable build', 'wp-crypto-direct-gateway'); ?></strong>
                            <p><?php esc_html_e('Run the packaging script from the plugin root to generate a distribution-ready zip in the dist folder.', 'wp-crypto-direct-gateway'); ?></p>
                            <code>./scripts/package-plugin.sh</code>
                        </div>
                    </aside>
                </div>

                <section class="wcdg-admin-panel">
                    <div class="wcdg-admin-panel-header">
                        <h2><?php esc_html_e('Wallets', 'wp-crypto-direct-gateway'); ?></h2>
                        <p><?php esc_html_e('Add one wallet per coin or network. Wallet templates ship without payout addresses, so you must paste your own address for each enabled row. Multi-network assets such as USDT should be added once per network so checkout and QR requests stay accurate.', 'wp-crypto-direct-gateway'); ?></p>
                    </div>

                    <p class="wcdg-table-scroll-hint"><?php esc_html_e('Wallet address is shown before the advanced QR columns. If you need the QR image or action columns, scroll sideways inside the table.', 'wp-crypto-direct-gateway'); ?></p>

                    <div class="wcdg-wallet-table-wrap">
                        <table class="widefat striped" id="wcdg-wallet-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Enabled', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Symbol', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Name', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Network', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Wallet address', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('CoinGecko ID', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Confirmations', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('QR mode', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Static QR image', 'wp-crypto-direct-gateway'); ?></th>
                                <th><?php esc_html_e('Actions', 'wp-crypto-direct-gateway'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($wallets as $index => $wallet) : ?>
                                <?php $this->render_wallet_row((string) $index, self::sanitize_wallet($wallet)); ?>
                            <?php endforeach; ?>
                        </tbody>
                        </table>
                    </div>

                    <p>
                        <button type="button" class="button button-secondary" id="wcdg-add-wallet"><?php esc_html_e('Add wallet', 'wp-crypto-direct-gateway'); ?></button>
                    </p>

                    <template id="wcdg-wallet-row-template">
                        <?php $this->render_wallet_row('__INDEX__', self::sanitize_wallet(array('enabled' => 1, 'confirmations' => 1))); ?>
                    </template>
                </section>

                <section class="wcdg-admin-panel">
                    <div class="wcdg-admin-panel-header">
                        <h2><?php esc_html_e('Integration details', 'wp-crypto-direct-gateway'); ?></h2>
                        <p><?php esc_html_e('Use these endpoints and shortcodes to embed or extend the gateway.', 'wp-crypto-direct-gateway'); ?></p>
                    </div>
                    <ul class="wcdg-detail-list">
                        <li><code><?php echo esc_html(rest_url('wcdg/v1/payment-requests')); ?></code> <?php esc_html_e('creates public payment requests.', 'wp-crypto-direct-gateway'); ?></li>
                        <li><code><?php echo esc_html(rest_url('wcdg/v1/payment-requests/{reference}/status')); ?></code> <?php esc_html_e('accepts callback updates from your payment watcher.', 'wp-crypto-direct-gateway'); ?></li>
                        <li><code>[wcdg_payment_form amount="49.99" currency="USD"]</code> <?php esc_html_e('renders a QR payment form anywhere on the site.', 'wp-crypto-direct-gateway'); ?></li>
                    </ul>
                </section>

                <?php submit_button(__('Save settings', 'wp-crypto-direct-gateway')); ?>
            </form>
        </div>
        <?php
    }

    public function render_wallet_row(string $index, array $wallet): void
    {
        ?>
        <tr class="wcdg-wallet-row">
            <td><input type="hidden" name="wallets[<?php echo esc_attr($index); ?>][uid]" value="<?php echo esc_attr($wallet['uid']); ?>" /><input type="checkbox" name="wallets[<?php echo esc_attr($index); ?>][enabled]" value="1" <?php checked((bool) $wallet['enabled']); ?> /></td>
            <td><input type="text" class="regular-text" name="wallets[<?php echo esc_attr($index); ?>][symbol]" value="<?php echo esc_attr($wallet['symbol']); ?>" placeholder="<?php esc_attr_e('BTC', 'wp-crypto-direct-gateway'); ?>" /></td>
            <td><input type="text" class="regular-text" name="wallets[<?php echo esc_attr($index); ?>][name]" value="<?php echo esc_attr($wallet['name']); ?>" placeholder="<?php esc_attr_e('Bitcoin', 'wp-crypto-direct-gateway'); ?>" /></td>
            <td><input type="text" class="regular-text" name="wallets[<?php echo esc_attr($index); ?>][network]" value="<?php echo esc_attr($wallet['network']); ?>" placeholder="<?php esc_attr_e('Bitcoin, ERC20, TRC20…', 'wp-crypto-direct-gateway'); ?>" /></td>
            <td><input type="text" class="regular-text code wcdg-wallet-address" name="wallets[<?php echo esc_attr($index); ?>][address]" value="<?php echo esc_attr($wallet['address']); ?>" placeholder="<?php esc_attr_e('Paste your wallet address', 'wp-crypto-direct-gateway'); ?>" autocomplete="off" spellcheck="false" /></td>
            <td><input type="text" class="regular-text" name="wallets[<?php echo esc_attr($index); ?>][coingecko_id]" value="<?php echo esc_attr($wallet['coingecko_id']); ?>" /></td>
            <td><input type="number" class="small-text" min="1" name="wallets[<?php echo esc_attr($index); ?>][confirmations]" value="<?php echo esc_attr((string) $wallet['confirmations']); ?>" /></td>
            <td>
                <select name="wallets[<?php echo esc_attr($index); ?>][qr_display_mode]">
                    <option value="dynamic" <?php selected($wallet['qr_display_mode'], 'dynamic'); ?>><?php esc_html_e('Dynamic', 'wp-crypto-direct-gateway'); ?></option>
                    <option value="static" <?php selected($wallet['qr_display_mode'], 'static'); ?>><?php esc_html_e('Static image', 'wp-crypto-direct-gateway'); ?></option>
                </select>
            </td>
            <td>
                <div class="wcdg-qr-upload-field">
                    <input type="url" class="regular-text code" name="wallets[<?php echo esc_attr($index); ?>][static_qr_url]" value="<?php echo esc_attr($wallet['static_qr_url']); ?>" />
                    <button type="button" class="button wcdg-upload-qr"><?php esc_html_e('Choose image', 'wp-crypto-direct-gateway'); ?></button>
                </div>
                <p class="description"><?php esc_html_e('If you use a static QR image, it must encode the exact address in this row.', 'wp-crypto-direct-gateway'); ?></p>
            </td>
            <td><button type="button" class="button-link-delete wcdg-remove-wallet"><?php esc_html_e('Remove', 'wp-crypto-direct-gateway'); ?></button></td>
        </tr>
        <?php
    }

    public static function sanitize_wallet(array $wallet): array
    {
        $symbol = strtoupper(sanitize_text_field((string) ($wallet['symbol'] ?? '')));
        $network = sanitize_text_field((string) ($wallet['network'] ?? ''));
        $uid = sanitize_key((string) ($wallet['uid'] ?? self::build_wallet_uid($symbol, $network)));

        return array(
            'uid' => $uid,
            'enabled' => empty($wallet['enabled']) ? 0 : 1,
            'symbol' => $symbol,
            'name' => sanitize_text_field((string) ($wallet['name'] ?? '')),
            'network' => $network,
            'coingecko_id' => sanitize_key((string) ($wallet['coingecko_id'] ?? '')),
            'address' => (string) preg_replace('/\s+/', '', sanitize_text_field((string) ($wallet['address'] ?? ''))),
            'static_qr_url' => esc_url_raw((string) ($wallet['static_qr_url'] ?? '')),
            'qr_display_mode' => in_array((string) ($wallet['qr_display_mode'] ?? ''), array('dynamic', 'static'), true) ? (string) $wallet['qr_display_mode'] : 'dynamic',
            'confirmations' => max(1, absint($wallet['confirmations'] ?? 1)),
        );
    }

    private static function build_wallet_uid(string $symbol, string $network): string
    {
        $base = trim(strtolower($symbol . '-' . $network));
        $base = preg_replace('/[^a-z0-9]+/', '-', $base);

        return trim((string) $base, '-');
    }

}